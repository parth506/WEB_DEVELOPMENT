#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        int bob = 0, b = 2;
        int alice = 1;
        for (int i = 2; i <= n; ++i)
        {
            if (b != 0)
            {
                bob += i;
            }
            else
            {
            }
        }
    }
}