#include <bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string s;
    cin >> s;
    cout << s << endl;
    string p = "parth agrawal";
    cout << p << endl;
    cout << s + p << endl;
}