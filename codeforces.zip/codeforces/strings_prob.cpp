#include <bits/stdc++.h>

using namespace std;

int main()
{
    int tc;
    cin >> tc;
    while (tc--)
    {
        int n, d;
        cin >> n >> d;
        vector<int> a(n);
        for (int &x : a)
            cin >> x;
        sort(a.begin(), a.end());
        cout << (a.back() <= d || a[0] + a[1] <= d ? "YES" : "NO") << endl;
    }
}