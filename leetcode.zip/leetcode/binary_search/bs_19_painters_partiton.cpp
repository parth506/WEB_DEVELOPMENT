#include <bits/stdc++.h>
using namespace std;
int funct(vector<int> &arr, int mid)
{
    int stu = 1;
    int count = 0;
    for (int i = 0; i < arr.size(); ++i)
    {
        if (count + arr[i] <= mid)
        {
            count += arr[i];
        }
        else
        {
            ++stu;
            count = arr[i];
        }
    }
    return stu;
}

int findLargestMinDistance(vector<int> &boards, int k)
{
    //    Write your code here.
    int low = *max_element(boards.begin(), boards.end());
    int high = accumulate(boards.begin(), boards.end(), 0);
    while (low <= high)
    {
        int mid = low + (high - low) / 2;
        if (funct(boards, mid) <= k)
        {

            high = mid - 1;
        }
        else
        {
            low = mid + 1;
        }
    }
    return low;
}